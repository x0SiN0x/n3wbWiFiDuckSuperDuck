#pragma once
#include <ESPAsyncWebServer.h>
void init_live_routes(AsyncWebServer &server);
