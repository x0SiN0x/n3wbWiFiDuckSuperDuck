
#ifndef WEBUI_API_BACKEND_HPP
#define WEBUI_API_BACKEND_HPP

#include <ESPAsyncWebServer.h>

extern AsyncWebServer server;  // Refer to server defined in main.cpp
void setupWebAPI();

#endif
