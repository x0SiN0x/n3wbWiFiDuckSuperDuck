#pragma once
#include "parser.hpp"

DuckyOpcode getOpcodeForLine(const String& line);
