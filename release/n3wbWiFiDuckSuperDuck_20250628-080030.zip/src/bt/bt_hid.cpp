// Bluetooth HID placeholder
