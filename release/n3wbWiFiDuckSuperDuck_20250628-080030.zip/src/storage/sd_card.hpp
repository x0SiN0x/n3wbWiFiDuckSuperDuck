#pragma once

bool sd_init();
