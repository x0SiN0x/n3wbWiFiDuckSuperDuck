#pragma once

void storage_mount_msc_luns();
