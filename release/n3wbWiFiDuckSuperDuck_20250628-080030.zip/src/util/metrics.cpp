// Metrics: CPU, RAM, Flash
