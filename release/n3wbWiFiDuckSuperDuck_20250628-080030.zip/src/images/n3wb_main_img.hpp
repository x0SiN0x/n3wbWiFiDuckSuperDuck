#pragma once
#include <stdint.h>

// Simulated 160x80 RGB565 image (placeholder: all white)
const uint16_t n3wb_main_img[160 * 80] = { 0xFFFF };
