#pragma once
void send_mouse_move(int dx, int dy);
