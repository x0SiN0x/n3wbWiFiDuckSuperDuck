#pragma once
#include <ESPAsyncWebServer.h>
void init_api_routes(AsyncWebServer &server);
