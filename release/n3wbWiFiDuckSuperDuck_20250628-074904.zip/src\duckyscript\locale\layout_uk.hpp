// UK layout key mappings
#pragma once
