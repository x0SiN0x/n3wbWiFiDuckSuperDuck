#pragma once
void draw_builtin_image(bool evil = false);
