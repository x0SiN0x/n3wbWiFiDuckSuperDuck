#pragma once
#include <Arduino.h>

// Execute a full DuckyScript from any Stream source
void runScript(Stream& stream);
