// US layout key mappings
#pragma once

// Example: #define HID_KEY_A 0x04
