// FR layout key mappings
#pragma once
