#pragma once
#include "parser.hpp"

void executeInstruction(const Instruction& instr);
