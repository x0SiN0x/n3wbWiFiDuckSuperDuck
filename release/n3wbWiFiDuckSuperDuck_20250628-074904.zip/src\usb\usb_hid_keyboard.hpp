#pragma once
void send_hid_string(const char* text);
void send_hid_key(const char* key);
void send_hid_key_combo(const char* combo);
