// Core instruction implementations
