// Executes instructions line-by-line with timing/delays
