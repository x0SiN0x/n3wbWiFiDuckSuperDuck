#include "usb_hid_mouse.hpp"
void send_mouse_move(int dx, int dy) {
  // Stub implementation
}
