#pragma once
#include "LGFX_Config.hpp"

void draw_image(LGFX &tft, const char *path);
