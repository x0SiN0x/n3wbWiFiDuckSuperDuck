// Runtime configuration
#include "config.h"
void setupConfig() {}
